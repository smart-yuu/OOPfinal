#include "Wire.h"

Wire::Wire(const std::string& name)
    : name(name), value(LogicValue::UNKNOWN), driver_gate(nullptr) {}

const std::string& Wire::getName() const {
    return name;
}

void Wire::setValue(LogicValue val) {
    value = val;
}

LogicValue Wire::getValue() const {
    return value;
}

void Wire::setDriver(Gate* gate) {
    driver_gate = gate;
}

void Wire::addDrivenGate(Gate* gate) {
    driven_gates.push_back(gate);
}

Gate* Wire::getDriver() const {
    return driver_gate;
}

const std::vector<Gate*>& Wire::getDrivenGates() const {
    return driven_gates;
}
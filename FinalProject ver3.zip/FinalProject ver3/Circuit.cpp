#include "Circuit.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>
#include <queue>
#include <stdexcept>
#include <algorithm>

Circuit::~Circuit() {}

Wire* Circuit::findOrCreateWire(const std::string& name) {
    if (all_wires.find(name) == all_wires.end()) {
        all_wires[name] = std::make_unique<Wire>(name);
    }
    return all_wires[name].get();
}

bool Circuit::parseNetlist(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open netlist file " << filename << std::endl;
        return false;
    }

    std::string line;
    // Regex to capture gate instantiations: type, name (optional), and ports
    std::regex gate_regex(R"(^\s*(and|or|nand|nor|xor|xnor|not|buf)\s*(?:\w+\s*)?\(([^)]+)\)\s*;)");
    // Regex to capture wire declarations
    std::regex wire_regex(R"(^\s*(?:input|output|wire)\s+([^;]+);)");

    while (getline(file, line)) {
        std::smatch match;
        
        if (std::regex_search(line, match, wire_regex)) {
            std::string type_str;
            std::istringstream iss_type(line);
            iss_type >> type_str; // "input", "output", or "wire"

            std::string all_names = match[1].str();
            all_names.erase(std::remove(all_names.begin(), all_names.end(), ' '), all_names.end());
            
            std::stringstream ss(all_names);
            std::string name;
            while(getline(ss, name, ',')) {
                findOrCreateWire(name);
                if (type_str == "input") primary_input_names.push_back(name);
                else if (type_str == "output") primary_output_names.push_back(name);
            }
        } else if (std::regex_search(line, match, gate_regex)) {
            std::string gate_type = match[1].str();
            std::string port_list_str = match[2].str();
            port_list_str.erase(std::remove(port_list_str.begin(), port_list_str.end(), ' '), port_list_str.end());
            
            std::vector<Wire*> port_wires;
            std::stringstream ss(port_list_str);
            std::string wire_name;
            while(getline(ss, wire_name, ',')) {
                port_wires.push_back(findOrCreateWire(wire_name));
            }

            if (port_wires.empty()) continue;

            Wire* output = port_wires[0];
            std::vector<Wire*> inputs(port_wires.begin() + 1, port_wires.end());
            
            Gate* new_gate = nullptr;
            if (gate_type == "and") new_gate = new AndGate(output, inputs);
            else if (gate_type == "or") new_gate = new OrGate(output, inputs);
            else if (gate_type == "nand") new_gate = new NandGate(output, inputs);
            else if (gate_type == "nor") new_gate = new NorGate(output, inputs);
            else if (gate_type == "xor") new_gate = new XorGate(output, inputs);
            else if (gate_type == "xnor") new_gate = new XnorGate(output, inputs);
            else if (gate_type == "not") new_gate = new NotGate(output, inputs);
            else if (gate_type == "buf") new_gate = new BufGate(output, inputs);

            if (new_gate) {
                all_gates.emplace_back(new_gate);
                output->setDriver(new_gate);
                for(auto in_wire : inputs) {
                    in_wire->addDrivenGate(new_gate);
                }
            }
        }
    }
    topologicalSort();
    return true;
}

void Circuit::topologicalSort() {
    std::map<Gate*, int> in_degree;
    std::queue<Gate*> q;

    for (auto const& gate_ptr : all_gates) {
        Gate* gate = gate_ptr.get();
        int degree = 0;
        for (Wire* in_wire : gate->getInputWires()) {
            // input wire from another is unknown value
            if (in_wire->getDriver() != nullptr) {
                degree++;
            }
        }
        in_degree[gate] = degree;
        if (degree == 0) {
            q.push(gate);
        }
    }

    while (!q.empty()) {
        Gate* u = q.front();
        q.pop();
        sorted_gates.push_back(u);

        Wire* out_wire = u->getOutputWire();
        for (Gate* v : out_wire->getDrivenGates()) {
            in_degree[v]--;
            if (in_degree[v] == 0) {
                q.push(v);
            }
        }
    }

    if (sorted_gates.size() != all_gates.size()) {
        std::cerr << "Warning: Combinational loop detected in the circuit. Simulation may be incorrect." << std::endl;
    }
}

void Circuit::resetWireValues() {
    for (const auto& pair : all_wires) {
        pair.second->setValue(LogicValue::UNKNOWN);
    }
}

void Circuit::simulate(const std::string& pattern_filename, const std::string& output_filename) {
    std::ifstream pat_file(pattern_filename);
    if (!pat_file.is_open()) {
        std::cerr << "Error: Could not open pattern file " << pattern_filename << std::endl;
        return;
    }

    std::ofstream out_file(output_filename);
    if (!out_file.is_open()) {
        std::cerr << "Error: Could not open output file " << output_filename << std::endl;
        return;
    }

    std::string line;
    std::vector<std::string> pat_input_names;

    // Read header
    if (getline(pat_file, line)) {
        std::istringstream iss(line);
        std::string keyword, name;
        iss >> keyword; // "input"
        while (iss >> name) {
            if (name.back() == ',') name.pop_back();
            pat_input_names.push_back(name);
        }
    }

    // Write output header
    out_file << "output ";
    for (size_t i = 0; i < primary_output_names.size(); ++i) {
        out_file << primary_output_names[i] << (i == primary_output_names.size() - 1 ? "" : ", ");
    }
    out_file << std::endl;

    // Process patterns
    while (getline(pat_file, line) && line.find(".end") == std::string::npos) {
        resetWireValues();
        std::istringstream iss(line);
        char val;
        for (const auto& input_name : pat_input_names) {
            if (iss >> val) {
                try {
                    all_wires.at(input_name)->setValue(fromChar(val));
                } catch(const std::out_of_range& e) {
                    std::cerr << "Error: Input wire '" << input_name << "' from pattern file not found in netlist." << std::endl;
                }
            }
        }

        // Evaluate gates in topological order
        for (Gate* gate : sorted_gates) {
            gate->getOutputWire()->setValue(gate->evaluate());
        }

        // Write output values
        for (size_t i = 0; i < primary_output_names.size(); ++i) {
            out_file << toChar(all_wires.at(primary_output_names[i])->getValue())<<' ';
        }
        out_file << std::endl;
    }

    out_file << ".end" << std::endl;
}
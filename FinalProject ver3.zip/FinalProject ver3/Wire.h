#ifndef WIRE_H
#define WIRE_H

#include <string>
#include <vector>
#include "LogicValue.h"

class Gate; // Forward declaration to resolve circular dependency

class Wire {
public:
    Wire(const std::string& name);

    const std::string& getName() const;
    void setValue(LogicValue val);
    LogicValue getValue() const;

    void setDriver(Gate* gate);
    void addDrivenGate(Gate* gate);

    Gate* getDriver() const;
    const std::vector<Gate*>& getDrivenGates() const;

private:
    std::string name;
    LogicValue value;
    Gate* driver_gate;
    std::vector<Gate*> driven_gates;
};

#endif // WIRE_H
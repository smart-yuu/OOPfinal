#ifndef CIRCUIT_H
#define CIRCUIT_H

#include <string>
#include <vector>
#include <map>
#include <memory>
#include "Gate.h"
#include "Wire.h"

class Circuit {
public:
    ~Circuit();

    bool parseNetlist(const std::string& filename);
    void simulate(const std::string& pattern_filename, const std::string& output_filename);

private:
    void topologicalSort();
    Wire* findOrCreateWire(const std::string& name);
    void resetWireValues();

    std::map<std::string, std::unique_ptr<Wire>> all_wires;
    std::vector<std::unique_ptr<Gate>> all_gates;
    
    std::vector<std::string> primary_input_names;
    std::vector<std::string> primary_output_names;

    std::vector<Gate*> sorted_gates;
};

#endif // CIRCUIT_H
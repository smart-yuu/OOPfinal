#ifndef GATE_H
#define GATE_H

#include <string>
#include <vector>
#include <memory>
#include "LogicValue.h"
#include "Wire.h"

// Abstract Base Class for all logic gates
class Gate {
public:
    Gate(Wire* out, const std::vector<Wire*>& ins);
    virtual ~Gate() = default; // Virtual destructor for polymorphism

    // Pure virtual function for gate evaluation
    virtual LogicValue evaluate() = 0;

    Wire* getOutputWire() const;
    const std::vector<Wire*>& getInputWires() const;

protected:
    Wire* output_wire;
    std::vector<Wire*> input_wires;
};

// Concrete Gate Implementations
class AndGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class OrGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class NandGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class NorGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class XorGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class XnorGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class NotGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

class BufGate : public Gate {
public:
    using Gate::Gate;
    LogicValue evaluate() override;
};

#endif // GATE_H
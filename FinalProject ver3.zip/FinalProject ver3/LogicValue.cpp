#include "LogicValue.h"
#include <stdexcept>

char toChar(LogicValue val) {
    switch (val) {
        case LogicValue::ZERO:    return '0';
        case LogicValue::ONE:     return '1';
        case LogicValue::UNKNOWN: return 'X';
    }
    return 'X'; // Should not be reached
}

LogicValue fromChar(char c) {
    switch (c) {
        case '0': return LogicValue::ZERO;
        case '1': return LogicValue::ONE;
        case 'X': return LogicValue::UNKNOWN;
        default:  throw std::invalid_argument("Invalid character for LogicValue");
    }
}

// AND Gate Logic
LogicValue operator&(LogicValue a, LogicValue b) {
    if (a == LogicValue::ZERO || b == LogicValue::ZERO) return LogicValue::ZERO;
    if (a == LogicValue::UNKNOWN || b == LogicValue::UNKNOWN) return LogicValue::UNKNOWN;
    return LogicValue::ONE;
}

// OR Gate Logic
LogicValue operator|(LogicValue a, LogicValue b) {
    if (a == LogicValue::ONE || b == LogicValue::ONE) return LogicValue::ONE;
    if (a == LogicValue::UNKNOWN || b == LogicValue::UNKNOWN) return LogicValue::UNKNOWN;
    return LogicValue::ZERO;
}

// XOR Gate Logic
LogicValue operator^(LogicValue a, LogicValue b) {
    if (a == LogicValue::UNKNOWN || b == LogicValue::UNKNOWN) return LogicValue::UNKNOWN;
    return (a == b) ? LogicValue::ZERO : LogicValue::ONE;
}

// NOT Gate Logic
LogicValue operator~(LogicValue a) {
    if (a == LogicValue::UNKNOWN) return LogicValue::UNKNOWN;
    return (a == LogicValue::ZERO) ? LogicValue::ONE : LogicValue::ZERO;
}
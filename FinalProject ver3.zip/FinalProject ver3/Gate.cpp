    #include "Gate.h"

Gate::Gate(Wire* out, const std::vector<Wire*>& ins)
    : output_wire(out), input_wires(ins) {}

Wire* Gate::getOutputWire() const {
    return output_wire;
}

const std::vector<Wire*>& Gate::getInputWires() const {
    return input_wires;
}

// --- Gate Evaluation Implementations ---

LogicValue AndGate::evaluate() {
    return input_wires[0]->getValue() & input_wires[1]->getValue();
}

LogicValue OrGate::evaluate() {
    return input_wires[0]->getValue() | input_wires[1]->getValue();
}

LogicValue NandGate::evaluate() {
    return ~(input_wires[0]->getValue() & input_wires[1]->getValue());
}

LogicValue NorGate::evaluate() {
    return ~(input_wires[0]->getValue() | input_wires[1]->getValue());
}

LogicValue XorGate::evaluate() {
    return input_wires[0]->getValue() ^ input_wires[1]->getValue();
}

LogicValue XnorGate::evaluate() {
    return ~(input_wires[0]->getValue() ^ input_wires[1]->getValue());
}

LogicValue NotGate::evaluate() {
    return ~input_wires[0]->getValue();
}

LogicValue BufGate::evaluate() {
    return input_wires[0]->getValue();
}
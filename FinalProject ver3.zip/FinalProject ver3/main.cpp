#include <iostream>
#include <string>
#include <vector>
#include "Circuit.h"

void printUsage() {
    std::cout << "Usage: ./ls -i <netlist.v> -p <pattern.pat> -o <output.out>" << std::endl;
}

int main(int argc, char* argv[]) {
    std::string netlist_file;
    std::string pattern_file;
    std::string output_file;

    if (argc != 7) {
        printUsage();
        return 1;
    }

    for (int i = 1; i < argc; i += 2) {
        std::string arg = argv[i];
        if (arg == "-i") {
            netlist_file = argv[i + 1];
        } else if (arg == "-p") {
            pattern_file = argv[i + 1];
        } else if (arg == "-o") {
            output_file = argv[i + 1];
        } else {
            printUsage();
            return 1;
        }
    }

    if (netlist_file.empty() || pattern_file.empty() || output_file.empty()) {
        printUsage();
        return 1;
    }

    Circuit circuit;
    
    if (!circuit.parseNetlist(netlist_file)) {
        return 1;
    }

    circuit.simulate(pattern_file, output_file);

    return 0;
}
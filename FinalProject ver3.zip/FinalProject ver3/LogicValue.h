#ifndef LOGIC_VALUE_H
#define LOGIC_VALUE_H

// Enum for the three logic states required: 0, 1, and X (unknown)
enum class LogicValue {
    ZERO,
    ONE,
    UNKNOWN
};

// Helper functions for character conversion
char toChar(LogicValue val);
LogicValue fromChar(char c);

// Operator overloads to implement truth tables cleanly
LogicValue operator&(LogicValue a, LogicValue b); // AND
LogicValue operator|(LogicValue a, LogicValue b); // OR
LogicValue operator^(LogicValue a, LogicValue b); // XOR
LogicValue operator~(LogicValue a);              // NOT

#endif // LOGIC_VALUE_H